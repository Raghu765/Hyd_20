package transport;
import transport.*;

public class Main {
	public static void main(String[] args) {
		car obj=new car();
		train obj1=new train();
		bus obj2=new bus();
		obj.vehicle();
		obj1.vehicle();
		obj2.vehicle();
	}

}

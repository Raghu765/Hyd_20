package transport;

public class train {
	public void vehicle() {
		System.out.println("cost");
	}

}

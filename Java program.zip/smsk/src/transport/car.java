package transport;

public class car {
	public void vehicle() {
		System.out.println("speed");
	}

}

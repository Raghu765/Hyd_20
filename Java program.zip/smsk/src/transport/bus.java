package transport;

public class bus {
	public void vehicle() {
		System.out.println("comfort");
	}
}

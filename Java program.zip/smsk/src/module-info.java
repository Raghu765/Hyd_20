/**
 * 
 */
/**
 * 
 */
module smsk {
}
package com.example.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementMgmtCollegeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementMgmtCollegeApplication.class, args);
	}

	public static void setLocation(String location) {
		// TODO Auto-generated method stub
		
	}

	public static void setcollegeName(String collegeName) {
		// TODO Auto-generated method stub
		
	}

	public static void setlocation(String location) {
		// TODO Auto-generated method stub
		
	}

}

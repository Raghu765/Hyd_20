package com.example.demo.Service;

import java.util.List;

import com.example.demo.Entity.College;

public interface CollegeService {

	College saveCollege(College college);

	List<College> fetchCollegeList();

	College fetchById(Long id);

	void deleteCollegeById(Long id);

	College updateCollege(Long id, College college);


	


	}
